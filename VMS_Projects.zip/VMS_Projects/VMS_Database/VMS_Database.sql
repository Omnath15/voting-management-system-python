Create Database VMS;
use VMS;
Create Table Login
(
	Name char(30) not null,
    Contact_Number bigint not null primary key,
    Email varchar(30) not null unique,
    User_Id varchar(30)not null unique,
    Password varchar(30) not null
);
select * from Login;

