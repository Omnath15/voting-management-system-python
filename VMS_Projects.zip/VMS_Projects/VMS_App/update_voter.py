import tkinter as tk
from tkinter import messagebox, filedialog
import mysql.connector
from PIL import Image, ImageTk
import os
import re

# ---------- DATABASE ----------
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="VMS"
    )

# ---------- MAIN ----------
def open_update_page(parent):
    win = tk.Toplevel(parent)
    win.title("Update Voter Details")
    win.state("zoomed")
    win.config(bg="#f4f6f7")

    # HEADER
    tk.Label(win, text="Voter Update Portal",
             font=("Arial", 22, "bold"),
             bg="#2C3E50", fg="white",
             pady=10).pack(fill="x")

    main_frame = tk.Frame(win, bg="#f4f6f7")
    main_frame.pack(fill="both", expand=True, padx=20, pady=20)

    # -------- 3 COLUMN LAYOUT --------
    left_frame = tk.Frame(main_frame, bg="white", bd=2, relief="groove")
    center_frame = tk.Frame(main_frame, bg="white", bd=2, relief="groove")
    right_frame = tk.Frame(main_frame, bg="white", bd=2, relief="groove")

    left_frame.grid(row=0, column=0, sticky="nsew", padx=10)
    center_frame.grid(row=0, column=1, sticky="nsew", padx=10)
    right_frame.grid(row=0, column=2, sticky="nsew", padx=10)

    main_frame.grid_columnconfigure(0, weight=1)
    main_frame.grid_columnconfigure(1, weight=1)
    main_frame.grid_columnconfigure(2, weight=1)

    # -------- COMMON ENTRY --------
    def create_entry(parent, label):
        tk.Label(parent, text=label, bg="white",
                 font=("Arial", 11, "bold")).pack(anchor="w", padx=15, pady=2)
        entry = tk.Entry(parent, font=("Arial", 11))
        entry.pack(fill="x", padx=15, pady=5)
        return entry

    # -------- LEFT (PERSONAL) --------
    tk.Label(left_frame, text="Personal Details",
             bg="#3498db", fg="white",
             font=("Arial", 14, "bold")).pack(fill="x")

    eci_entry = create_entry(left_frame, "ECI Number *")
    fname_entry = create_entry(left_frame, "First Name")
    lname_entry = create_entry(left_frame, "Last Name")
    father_entry = create_entry(left_frame, "Father Name")
    mobile_entry = create_entry(left_frame, "Mobile")
    email_entry = create_entry(left_frame, "Email")
    aadhar_entry = create_entry(left_frame, "Aadhaar Number")

    # -------- CENTER (ADDRESS) --------
    tk.Label(center_frame, text="Address Details",
             bg="#27ae60", fg="white",
             font=("Arial", 14, "bold")).pack(fill="x")

    house_entry = create_entry(center_frame, "House No")
    street_entry = create_entry(center_frame, "Street")
    village_entry = create_entry(center_frame, "Village")
    post_entry = create_entry(center_frame, "Post Office")
    district_entry = create_entry(center_frame, "District")
    pin_entry = create_entry(center_frame, "PIN Code")
    state_entry = create_entry(center_frame, "State")

    # -------- RIGHT (PHOTO + BUTTONS) --------
    tk.Label(right_frame, text="Photo & Actions",
             bg="#8e44ad", fg="white",
             font=("Arial", 14, "bold")).pack(fill="x")

    photo_path = tk.StringVar()
    sign_path = tk.StringVar()

    photo_label = tk.Label(right_frame, bg="white")
    photo_label.pack(pady=10)

    sign_label = tk.Label(right_frame, bg="white")
    sign_label.pack(pady=10)

    # PHOTO
    def upload_photo():
        path = filedialog.askopenfilename(filetypes=[("Image", "*.jpg *.png *.jpeg")])
        if path:
            photo_path.set(path)
            img = Image.open(path).resize((120, 120))
            img = ImageTk.PhotoImage(img)
            photo_label.config(image=img)
            photo_label.image = img

    def clear_photo():
        photo_path.set("")
        photo_label.config(image="")
        photo_label.image = None

    # SIGN
    def upload_sign():
        path = filedialog.askopenfilename(filetypes=[("Image", "*.jpg *.png *.jpeg")])
        if path:
            sign_path.set(path)
            img = Image.open(path).resize((120, 60))
            img = ImageTk.PhotoImage(img)
            sign_label.config(image=img)
            sign_label.image = img

    def clear_sign():
        sign_path.set("")
        sign_label.config(image="")
        sign_label.image = None

    # BUTTONS
    tk.Button(right_frame, text="Upload Photo", command=upload_photo,
              bg="#8e44ad", fg="white", width=20).pack(pady=5)

    tk.Button(right_frame, text="Clear Photo", command=clear_photo,
              bg="#c0392b", fg="white", width=20).pack(pady=5)

    tk.Button(right_frame, text="Upload Signature", command=upload_sign,
              bg="#16a085", fg="white", width=20).pack(pady=5)

    tk.Button(right_frame, text="Clear Signature", command=clear_sign,
              bg="#e74c3c", fg="white", width=20).pack(pady=5)

    # -------- FETCH --------
    def fetch_data():
        eci = eci_entry.get()
        if not eci:
            messagebox.showerror("Error", "Enter ECI Number")
            return

        con = get_db_connection()
        cur = con.cursor()

        cur.execute("SELECT * FROM voter_registration WHERE eci_number=%s", (eci,))
        data = cur.fetchone()

        if not data:
            messagebox.showerror("Error", "Not Found")
            return

        # CLEAR + INSERT
        fields = [
            (fname_entry, data[2]),
            (lname_entry, data[3]),
            (father_entry, data[4]),
            (mobile_entry, data[6]),
            (email_entry, data[7]),
            (aadhar_entry, data[8]),
            (house_entry, data[10]),
            (street_entry, data[11]),
            (village_entry, data[12]),
            (post_entry, data[13]),
            (district_entry, data[14]),
            (pin_entry, data[15]),
            (state_entry, data[16]),
        ]

        for e, v in fields:
            e.delete(0, tk.END)
            e.insert(0, v or "")

        # PHOTO
        if data[17] and os.path.exists(data[17]):
            img = Image.open(data[17]).resize((120, 120))
            img = ImageTk.PhotoImage(img)
            photo_label.config(image=img)
            photo_label.image = img
            photo_path.set(data[17])

        # SIGN
        if data[18] and os.path.exists(data[18]):
            img = Image.open(data[18]).resize((120, 60))
            img = ImageTk.PhotoImage(img)
            sign_label.config(image=img)
            sign_label.image = img
            sign_path.set(data[18])

        con.close()

    tk.Button(right_frame, text="Fetch Data", command=fetch_data,
              bg="#2980b9", fg="white", width=20).pack(pady=15)

    # -------- VALIDATION --------
    def validate():
        if mobile_entry.get() and not re.fullmatch(r"[6-9]\d{9}", mobile_entry.get()):
            messagebox.showerror("Error", "Invalid Mobile")
            return False
        if aadhar_entry.get() and not re.fullmatch(r"\d{12}", aadhar_entry.get()):
            messagebox.showerror("Error", "Invalid Aadhaar")
            return False
        if pin_entry.get() and not re.fullmatch(r"\d{6}", pin_entry.get()):
            messagebox.showerror("Error", "Invalid PIN")
            return False
        return True

    # -------- UPDATE --------
    def update_data():
        if not validate():
            return

        con = get_db_connection()
        cur = con.cursor()

        cur.execute("""
            UPDATE voter_registration SET
            first_name=%s, last_name=%s, father_name=%s,
            mobile=%s, email=%s, aadhar=%s,
            house_no=%s, street=%s, village=%s,
            post_office=%s, district=%s, pin_code=%s, state=%s,
            photo_path=%s, sign_path=%s
            WHERE eci_number=%s
        """, (
            fname_entry.get(),
            lname_entry.get(),
            father_entry.get(),
            mobile_entry.get(),
            email_entry.get(),
            aadhar_entry.get(),
            house_entry.get(),
            street_entry.get(),
            village_entry.get(),
            post_entry.get(),
            district_entry.get(),
            pin_entry.get(),
            state_entry.get(),
            photo_path.get(),
            sign_path.get(),
            eci_entry.get()
        ))

        con.commit()
        con.close()

        messagebox.showinfo("Success", "Updated Successfully")

    tk.Button(right_frame, text="Update Data",
              command=update_data,
              bg="#27ae60", fg="white",
              width=20).pack(pady=5)

    #win.mainloop()
#open_update_page()