import tkinter as tk
from tkinter import messagebox
import random, string, re
import mysql.connector
from Dashboard import open_dashboard
from New_User import open_signup
from Forget_Password import open_forgot_password
# ------------------ DATABASE ------------------
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="VMS"
    )
#current_window=None
# ------------------ CAPTCHA ------------------
def generate_captcha():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))

def refresh_captcha():
    captcha_var.set(generate_captcha())

# ------------------ CENTER WINDOW ------------------
def center_window(win, w=600, h=500):
    ws = win.winfo_screenwidth()
    hs = win.winfo_screenheight()
    x = int((ws/2) - (w/2))
    y = int((hs/2) - (h/2))
    win.geometry(f"{w}x{h}+{x}+{y}")

# ------------------ BUTTON HOVER EFFECT ------------------
def on_enter(e):
    e.widget['bg'] = "#1abc9c"

def on_leave(e):
    e.widget['bg'] = "#16a085"

# ------------------ LOGIN FUNCTION ------------------
def login():
    uid = user_entry.get()
    pwd = pass_entry.get()
    cap = captcha_entry.get()

    if not uid or not pwd or not cap:
        messagebox.showerror("Error", "All fields are required")
        return

    if not re.match(r"^[A-Za-z0-9_]{4,}$", uid):
        messagebox.showerror("Error", "Invalid User ID")
        return

    if cap != captcha_var.get():
        messagebox.showerror("Error", "Wrong Captcha")
        refresh_captcha()
        return

    try:
        conn = connect_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM Login WHERE User_Id=%s AND Password=%s", (uid, pwd))
        if cur.fetchone():
            messagebox.showinfo("Success", "Login Successful 🎉")
            #root.destroy()   # close login window
            root.withdraw()
            open_dashboard(uid)   # open dashboard
        else:
            messagebox.showerror("Error", "Invalid Credentials")
    except Exception as e:
        messagebox.showerror("DB Error", str(e))

# ------------------ CLEAR ------------------
def clear():
    user_entry.delete(0, tk.END)
    pass_entry.delete(0, tk.END)
    captcha_entry.delete(0, tk.END)

# ------------------ UI ROOT Design------------------
root = tk.Tk()
#root.geometry('1000x1000')
root.state("zoomed")   # For Windows maximized
root.resizable(False, False)# desiable maximized button
root.title("VMS Login System")
root.config(bg="#0f172a")

center_window(root)#center function call open page in center
tk.Label(root,text='Voting Management System',
         bg='#0f172a',fg='white',font=('Arial',40,'bold')).pack(pady=10)
# ------------------ MAIN FRAME ------------------
main_frame = tk.Frame(root, bg="white", bd=0)
main_frame.place(relx=0.5, rely=0.5, anchor="center", width=550, height=650)

# ------------------ TITLE ------------------
tk.Label(main_frame, text="Welcome Back", font=("Segoe UI", 20, "bold"),
         bg="white", fg="#0f172a").pack(pady=(20,5))

tk.Label(main_frame, text="Login to continue", font=("Segoe UI", 11),
         bg="white", fg="gray").pack(pady=(0,15))

# ------------------ USER ID ------------------
tk.Label(main_frame, text="User ID", font=("Segoe UI", 10, "bold"),
         bg="white").pack(anchor="w", padx=40)

user_entry = tk.Entry(main_frame, font=("Segoe UI", 15), bd=2, relief="groove")
user_entry.pack(padx=40, pady=8, ipady=6, fill="x")

# ------------------ PASSWORD ------------------
tk.Label(main_frame, text="Password", font=("Segoe UI", 10, "bold"),
         bg="white").pack(anchor="w", padx=40)

pass_entry = tk.Entry(main_frame, font=("Segoe UI", 12), show="*", bd=2, relief="groove")
pass_entry.pack(padx=40, pady=8, ipady=6, fill="x")

# ------------------ CAPTCHA ------------------
captcha_var = tk.StringVar()
captcha_var.set(generate_captcha())

tk.Label(main_frame, text="Captcha", font=("Segoe UI", 10, "bold"),
         bg="white").pack(anchor="w", padx=40)

captcha_frame = tk.Frame(main_frame, bg="white")
captcha_frame.pack(padx=40, pady=5, fill="x")

tk.Label(captcha_frame, textvariable=captcha_var, font=("Segoe UI", 14, "bold"),
         fg="#16a085", bg="#ecfdf5", width=8).pack(side="left", padx=(0,10))

tk.Button(captcha_frame, text="↻", font=("Segoe UI", 12),
          command=refresh_captcha, bg="#ecfdf5", bd=0).pack(side="left")

captcha_entry = tk.Entry(main_frame, font=("Segoe UI", 12), bd=2, relief="groove")
captcha_entry.pack(padx=40, pady=8, ipady=6, fill="x")

# ------------------ LOGIN BUTTON ------------------
login_btn = tk.Button(main_frame, text="Sign In", font=("Segoe UI", 12, "bold"),
                      bg="#16a085", fg="white", bd=0, cursor="hand2",
                      command=login)
login_btn.pack(pady=15, ipadx=10, ipady=6, fill="x", padx=40)

login_btn.bind("<Enter>", on_enter)
login_btn.bind("<Leave>", on_leave)

# ------------------ EXTRA BUTTONS ------------------
btn_frame = tk.Frame(main_frame, bg="white")
btn_frame.pack(pady=5)

tk.Button(btn_frame, text="Sign Up", font=("Segoe UI", 10),
          command=lambda: open_signup(root),
          bd=0, fg="#16a085", bg="white", cursor="hand2").grid(row=0, column=0, padx=10)

tk.Button(btn_frame, text="Forgot Password", font=("Segoe UI", 10),
          command=lambda: open_forgot_password(root),
          bd=0, fg="#16a085", bg="white", cursor="hand2").grid(row=0, column=1, padx=10)

tk.Button(main_frame, text="Clear", font=("Segoe UI", 10),
          command=clear, bd=0, bg="white", cursor="hand2",fg='#16a085').pack(pady=10, ipadx=10, ipady=4)

# ----------------------- RUN ---------------------------
root.mainloop()