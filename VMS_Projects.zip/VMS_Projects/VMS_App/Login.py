import tkinter as tk 
from Home import Home_page
from Home import About_page 
def Submit():
    #root.destroy()
    root.withdraw()
    Home_page(root)
root = tk.Tk()
root.title('this is main page')
root.geometry('600x600')
root.configure(bg='pink')
tk.Button(root, text="Home",
          bg="#2980B9", fg="white", width=20,
          command=Submit()).pack(pady=150)

tk.Button(root, text="About",
          bg="#2980B9", fg="white", width=30,
          command=lambda:About_page()).pack(pady=50)
root.mainloop()