import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pymysql
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Image, Paragraph
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
import os

def open_admin_panel(parent):

    win = tk.Toplevel(parent)
    win.title("Admin Panel")
    win.geometry("900x600")
    win.config(bg="#ecf0f1")

    tk.Label(win, text="🧑‍💼 Admin Panel",
             font=("Segoe UI", 22, "bold"),
             bg="#ecf0f1").pack(pady=10)

    notebook = ttk.Notebook(win)
    notebook.pack(fill="both", expand=True, padx=10, pady=10)

    # ================= DATABASE =================
    def get_conn():
        return pymysql.connect(host="localhost", user="root", password="root", database="VMS")

    # ================= VOTER TAB =================
    voter_tab = tk.Frame(notebook, bg="white")
    notebook.add(voter_tab, text="Voters")

    columns = ("ID", "Name", "Mobile", "Email", "ECI", "Voted")

    tree = ttk.Treeview(voter_tab, columns=columns, show="headings")
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=120)

    tree.pack(fill="both", expand=True, pady=10)

    # -------- LOAD VOTERS --------
    def load_voters():
        for row in tree.get_children():
            tree.delete(row)

        conn = get_conn()
        cur = conn.cursor()

        cur.execute("""
        SELECT id, CONCAT(first_name,' ',last_name), mobile, email, eci_number, has_voted
        FROM voter_registration
        """)

        for row in cur.fetchall():
            tree.insert("", "end", values=row)

        conn.close()

    # -------- EXPORT PDF --------
    def export_pdf():
        try:
            conn = get_conn()
            cur = conn.cursor()

            cur.execute("""
            SELECT id, CONCAT(first_name,' ',last_name), mobile, email, eci_number, has_voted,photo_path
            FROM voter_registration
            """)

            data = cur.fetchall()
            conn.close()

            if not data:
                messagebox.showinfo("No Data", "No voters found")
                return

            file_path = filedialog.asksaveasfilename(
                defaultextension=".pdf",
                filetypes=[("PDF File", "*.pdf")]
            )

            if not file_path:
                return

            doc = SimpleDocTemplate(file_path, pagesize=A4)
            elements = []

            styles = getSampleStyleSheet()
            elements.append(Paragraph("Voter Report", styles["Title"]))

            table_data = [["ID", "Name", "Mobile", "Email", "ECI", "Voted", "Photo"]]

            for row in data:
                voter_row = list(row[:6])

                img_path = row[6]
                if img_path and os.path.exists(img_path):
                    img = Image(img_path, width=40, height=40)
                    voter_row.append(img)
                else:
                    voter_row.append("No Image")

                table_data.append(voter_row)

            table = Table(table_data, repeatRows=1)

            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ]))

            elements.append(table)
            doc.build(elements)

            messagebox.showinfo("Success", "PDF Generated Successfully!")

        except Exception as e:
            messagebox.showerror("Error", str(e))

    # -------- DELETE VOTER --------
    def delete_voter():
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select voter first")
            return

        voter_id = tree.item(selected[0])["values"][0]

        conn = get_conn()
        cur = conn.cursor()
        cur.execute("DELETE FROM voter_registration WHERE id=%s", (voter_id,))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Voter deleted")
        load_voters()

    # -------- SEARCH --------
    search_var = tk.StringVar()

    def search_voter():
        text = search_var.get()

        for row in tree.get_children():
            tree.delete(row)

        conn = get_conn()
        cur = conn.cursor()

        cur.execute("""
        SELECT id, CONCAT(first_name,' ',last_name), mobile, email, eci_number, has_voted
        FROM voter_registration
        WHERE first_name LIKE %s OR eci_number LIKE %s
        """, (f"%{text}%", f"%{text}%"))

        for row in cur.fetchall():
            tree.insert("", "end", values=row)

        conn.close()

    # -------- TOP BUTTONS --------
    top_frame = tk.Frame(voter_tab, bg="white")
    top_frame.pack()

    tk.Entry(top_frame, textvariable=search_var).pack(side="left", padx=5)
    tk.Button(top_frame, text="Search", command=search_voter).pack(side="left", padx=5)
    tk.Button(top_frame, text="Refresh", command=load_voters).pack(side="left", padx=5)
    tk.Button(top_frame, text="Delete", command=delete_voter, bg="red", fg="white").pack(side="left", padx=5)
    tk.Button(top_frame, text="📄 Download PDF", bg="#e67e22", fg="white",
              command=export_pdf).pack(side="left", padx=5)

    load_voters()

    # ================= VOTES TAB =================
    vote_tab = tk.Frame(notebook, bg="white")
    notebook.add(vote_tab, text="Votes")

    vote_tree = ttk.Treeview(vote_tab, columns=("ECI", "Party", "Time"), show="headings")

    for col in ("ECI", "Party", "Time"):
        vote_tree.heading(col, text=col)
        vote_tree.column(col, width=150)

    vote_tree.pack(fill="both", expand=True, pady=10)

    def load_votes():
        for row in vote_tree.get_children():
            vote_tree.delete(row)

        conn = get_conn()
        cur = conn.cursor()

        cur.execute("SELECT eci_number, party, vote_time FROM votes")

        for row in cur.fetchall():
            vote_tree.insert("", "end", values=row)

        conn.close()

    tk.Button(vote_tab, text="Refresh Votes",
              command=load_votes,
              bg="#2980b9", fg="white").pack(pady=5)

    load_votes()

    # ================= CONTROL TAB =================
    control_tab = tk.Frame(notebook, bg="white")
    notebook.add(control_tab, text="Control")

    def reset_votes():
        if not messagebox.askyesno("Confirm", "Reset all votes?"):
            return

        conn = get_conn()
        cur = conn.cursor()

        cur.execute("DELETE FROM votes")
        cur.execute("UPDATE voter_registration SET has_voted=0")

        conn.commit()
        conn.close()

        messagebox.showinfo("Done", "Voting reset successfully")

    tk.Label(control_tab, text="⚙ Election Control",
             font=("Segoe UI", 16, "bold"),
             bg="white").pack(pady=20)

    tk.Button(control_tab,
              text="🔄 Reset Voting",
              bg="red", fg="white",
              font=("Segoe UI", 12, "bold"),
              command=reset_votes).pack(pady=10)