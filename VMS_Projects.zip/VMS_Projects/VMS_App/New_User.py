import tkinter as tk
from tkinter import messagebox
import random
import smtplib
import pymysql
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# ------------------ DATABASE CONNECTION ------------------
def db_connect():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",   # change if needed
        database="VMS"
    )

# ------------------ SEND OTP EMAIL ------------------
def send_otp(email):
    global generated_otp
    generated_otp = str(random.randint(100000, 999999))

    sender_email = "om18niit@gmail.com"
    app_password = "gmwgfyotjrarpakm"

    try:
        msg = MIMEMultipart()
        msg["From"] = sender_email
        msg["To"] = email
        msg["Subject"] = "🔐 OTP Verification - VMS"

        html = f"""
        <html>
        <body style="font-family: Arial; background-color:#f4f4f4; padding:20px;">
            <div style="max-width:500px; margin:auto; background:white; padding:20px; border-radius:10px; text-align:center;">
                <h2 style="color:#2C3E50;">Voting Management System</h2>
                <p style="font-size:16px;">Your OTP for verification is:</p>
                <h1 style="color:#27AE60; letter-spacing:5px;">{generated_otp}</h1>
                <p style="color:red;">Do not share this OTP with anyone</p>
            </div>
        </body>
        </html>
        """

        msg.attach(MIMEText(html, "html"))

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()

        messagebox.showinfo("Success", "OTP sent successfully!")

    except Exception as e:
        messagebox.showerror("Error", str(e))

# ------------------ VERIFY OTP ------------------
def verify_otp():
    if otp_entry.get() == generated_otp:
        messagebox.showinfo("Success", "OTP Verified Successfully ✅")
        create_account()
    else:
        messagebox.showerror("Error", "Invalid OTP ❌")

# ------------------ CREATE ACCOUNT ------------------
def create_account():
    name = name_entry.get()
    contact = contact_entry.get()
    email = email_entry.get()
    user_id = user_entry.get()
    password = pass_entry.get()
    confirm = confirm_entry.get()

    if not all([name, contact, email, user_id, password, confirm]):
        messagebox.showerror("Error", "All fields are required")
        return

    if password != confirm:
        messagebox.showerror("Error", "Passwords do not match")
        return

    try:
        conn = db_connect()
        cursor = conn.cursor()

        query = "INSERT INTO Login VALUES (%s,%s,%s,%s,%s)"
        cursor.execute(query, (name, contact, email, user_id, password))
        conn.commit()
        conn.close()

        messagebox.showinfo("Success", "Account Created Successfully 🎉")

        send_welcome_email(email, name)

    except Exception as e:
        messagebox.showerror("Database Error", str(e))

# ------------------ WELCOME EMAIL ------------------
def send_welcome_email(email, name):
    sender_email = "om18niit@gmail.com"
    app_password = "gmwgfyotjrarpakm"

    try:
        msg = MIMEMultipart()
        msg["From"] = sender_email
        msg["To"] = email
        msg["Subject"] = "🎉 Welcome to VMS"

        html = f"""
        <html>
        <body style="font-family:Arial; background:#f4f4f4; padding:20px;">
            <div style="background:white; padding:20px; border-radius:10px;">
                <h2 style="color:#2980B9;">Welcome {name} 🎉</h2>
                <p>Your account has been successfully created.</p>
                <p>You can now login using your credentials.</p>
                <br>
                <p style="color:gray;">Thank you for joining VMS</p>
            </div>
        </body>
        </html>
        """

        msg.attach(MIMEText(html, "html"))

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()

    except Exception as e:
        print(e)

# ------------------ SIGNUP WINDOW ------------------
def open_signup(parent):
    '''global current_window
    if current_window:
        current_window.destroy()'''
    signup = tk.Toplevel(parent)
    signup.title("Sign Up")
    signup.geometry("500x700")
    signup.configure(bg="#1C2833")

    tk.Label(signup, text="Create Account", font=("Arial", 20, "bold"),
             bg="#1C2833", fg="white").pack(pady=15)

    def create_entry(label):
        tk.Label(signup, text=label, bg="#1C2833", fg="white",
                 font=("Arial", 11)).pack()
        entry = tk.Entry(signup, font=("Arial", 12), width=30, relief="flat")
        entry.pack(pady=5, ipady=5)
        return entry

    global name_entry, contact_entry, email_entry, user_entry
    global pass_entry, confirm_entry, otp_entry

    name_entry = create_entry("Full Name")
    contact_entry = create_entry("Contact Number")
    email_entry = create_entry("Email")
    user_entry = create_entry("User ID")

    pass_entry = create_entry("Password")
    pass_entry.config(show="*")

    confirm_entry = create_entry("Confirm Password")
    confirm_entry.config(show="*")

    tk.Button(signup, text="Send OTP",
              bg="#27AE60", fg="white", width=20,
              command=lambda: send_otp(email_entry.get())).pack(pady=10)

    otp_entry = create_entry("Enter OTP")

    tk.Button(signup, text="Verify & Register",
              bg="#2980B9", fg="white", width=20,
              command=verify_otp).pack(pady=20)


#root.mainloop()