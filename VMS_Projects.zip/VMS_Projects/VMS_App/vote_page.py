def open_vote_page(parent):

    import tkinter as tk
    from tkinter import messagebox
    import pymysql

    win = tk.Toplevel(parent)
    win.title("Vote Now")
    win.geometry("700x500")
    win.config(bg="#ecf0f1")

    tk.Label(win, text="🗳 Cast Your Vote",
             font=("Segoe UI", 20, "bold"),
             bg="#ecf0f1").pack(pady=20)

    # -------- INPUT --------
    tk.Label(win, text="Enter ECI Number").pack()
    eci_entry = tk.Entry(win, width=30)
    eci_entry.pack(pady=5)

    status_label = tk.Label(win, text="", bg="#ecf0f1", fg="green")
    status_label.pack()

    vote_frame = tk.Frame(win, bg="#ecf0f1")
    vote_frame.pack(pady=20)

    # -------- CHECK USER --------
    def check_eci():

        conn = pymysql.connect(host="localhost", user="root", password="root", database="VMS")
        cur = conn.cursor()

        cur.execute("SELECT has_voted FROM voter_registration WHERE eci_number=%s",
                    (eci_entry.get(),))

        result = cur.fetchone()
        conn.close()

        if not result:
            messagebox.showerror("Error", "Invalid ECI Number")
            return

        if result[0] == 1:
            messagebox.showwarning("Warning", "You have already voted")
            return

        status_label.config(text="✅ Verified! Now cast your vote")

        show_parties()

    tk.Button(win, text="Verify ECI", bg="#2980b9", fg="white",
              command=check_eci).pack(pady=10)

    # -------- PARTIES --------
    def show_parties():

        for widget in vote_frame.winfo_children():
            widget.destroy()

        parties = [
            ("BJP", "bjp.png"),
            ("Congress", "congress.png"),
            ("AAP", "aap.png"),
            ("Samajwadi Party", "sp.png"),
            ("BSP", "bsp.png")
        ]

        def cast_vote(party_name):

            conn = pymysql.connect(host="localhost", user="root", password="root", database="VMS")
            cur = conn.cursor()

            # insert vote
            cur.execute("INSERT INTO votes (eci_number, party) VALUES (%s,%s)",
                        (eci_entry.get(), party_name))

            # update status
            cur.execute("UPDATE voter_registration SET has_voted=1 WHERE eci_number=%s",
                        (eci_entry.get(),))

            conn.commit()
            conn.close()

            messagebox.showinfo("Success", f"Vote casted for {party_name}")
            win.destroy()

        # Display Parties
        for i, (party, logo) in enumerate(parties):

            frame = tk.Frame(vote_frame, bg="white", bd=1, relief="solid")
            frame.grid(row=i//2, column=i%2, padx=20, pady=10)

            try:
                from PIL import Image, ImageTk
                img = Image.open(logo).resize((80, 80))
                photo = ImageTk.PhotoImage(img)

                lbl = tk.Label(frame, image=photo)
                lbl.image = photo
                lbl.pack()

            except:
                tk.Label(frame, text="No Logo").pack()

            tk.Label(frame, text=party, font=("Segoe UI", 12, "bold")).pack()

            tk.Button(frame, text="Vote",
                      bg="#27ae60", fg="white",
                      command=lambda p=party: cast_vote(p)).pack(pady=5)