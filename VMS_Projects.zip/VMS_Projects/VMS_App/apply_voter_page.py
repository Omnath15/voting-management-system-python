import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import re
import random
import string
import smtplib
from email.mime.text import MIMEText
from io import BytesIO
import threading

try:
    import mysql.connector
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False

# ══════════════════════════════════════════════════════════════════════
#  CONFIGURE THESE BEFORE RUNNING
# ══════════════════════════════════════════════════════════════════════
DB_CONFIG = {
    "host":     "localhost",
    "port":     3306,
    "user":     "root",           # <- your MySQL username
    "password": "root",  # <- your MySQL password
    "database": "VMS",
}

# Gmail SMTP  — generate an App Password at:
# https://myaccount.google.com/apppasswords
SMTP_CONFIG = {
    "sender_email":    "om18niit@gmail.com",   # <- sender Gmail
    "sender_password": "gmwgfyotjrarpakm",       # <- Gmail App Password (16 chars)
    "smtp_host":       "smtp.gmail.com",
    "smtp_port":       587,
}
# ══════════════════════════════════════════════════════════════════════


# ─────────────────────── COLOUR PALETTE (Light) ───────────────────────
C = {
    "bg":         "#f0f4f8",
    "panel":      "#ffffff",
    "card":       "#f8fafc",
    "border":     "#c9d6e3",
    "accent1":    "#1a6eb5",
    "accent2":    "#0d9e6e",
    "warn":       "#d9363e",
    "text":       "#1a2535",
    "subtext":    "#5a7090",
    "entry_bg":   "#ffffff",
    "header_bg":  "#1a6eb5",
    "header_fg":  "#ffffff",
    "section_bg": "#e8f0fa",
    "section_fg": "#1a4a80",
    "btn_submit": "#1a6eb5",
    "btn_clear":  "#d9363e",
    "btn_otp":    "#0d7a5c",
    "btn_verify": "#0d9e6e",
    "ok_green":   "#0d9e6e",
}

F_HEAD  = ("Segoe UI", 17, "bold")
F_TITLE = ("Segoe UI", 13, "bold")
F_SEC   = ("Segoe UI", 10, "bold")
F_LBL   = ("Segoe UI", 9,  "bold")
F_ENTRY = ("Segoe UI", 11)
F_BTN   = ("Segoe UI", 10, "bold")
F_SMALL = ("Segoe UI", 8)


# ──────────────────────────── DB HELPERS ──────────────────────────────
def get_connection():
    if not MYSQL_AVAILABLE:
        raise RuntimeError(
            "mysql-connector-python not installed.\n"
            "Run:  pip install mysql-connector-python"
        )
    return mysql.connector.connect(**DB_CONFIG)


def save_voter(data):
    """Insert into VMS.voters; return generated ECI number."""
    eci = "ECI-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=10))
    conn   = get_connection()
    cursor = conn.cursor()
    sql = """
        INSERT INTO voters
          (first_name, last_name, father_name, dob, gender,
           mobile, email, aadhar,
           house, street, village, post_office, district, pin, state,
           eci_number, photo, signature)
        VALUES
          (%s, %s, %s, %s, %s,
           %s, %s, %s,
           %s, %s, %s, %s, %s, %s, %s,
           %s, %s, %s)
    """
    cursor.execute(sql, (
        data["first_name"], data["last_name"], data["father_name"],
        data["dob"],        data["gender"],
        data["mobile"],     data["email"],     data["aadhar"],
        data["house"],      data["street"],    data["village"],
        data["post_office"],data["district"],  data["pin"],
        data["state"],      eci,
        data["photo"],      data["signature"],
    ))
    conn.commit()
    cursor.close()
    conn.close()
    return eci


# ──────────────────────────── EMAIL OTP ───────────────────────────────
def send_otp_email(to_email, otp):
    body = (
        f"Dear Applicant,\n\n"
        f"Your OTP for Voter ID Registration is:\n\n"
        f"    {otp}\n\n"
        f"This OTP is valid for 10 minutes.\n"
        f"Do NOT share it with anyone.\n\n"
        f"— Election Commission of India, VMS Portal"
    )
    msg            = MIMEText(body)
    msg["Subject"] = f"Voter ID Registration OTP: {otp}"
    msg["From"]    = SMTP_CONFIG["sender_email"]
    msg["To"]      = to_email

    with smtplib.SMTP(SMTP_CONFIG["smtp_host"], SMTP_CONFIG["smtp_port"]) as server:
        server.starttls()
        server.login(SMTP_CONFIG["sender_email"], SMTP_CONFIG["sender_password"])
        server.sendmail(SMTP_CONFIG["sender_email"], to_email, msg.as_string())


# ──────────────────────── CONFIRMATION EMAIL ─────────────────────────
def send_confirmation_email(to_email, name, eci):
    body = f"""\
Dear {name},

🎉 Congratulations! Your Voter ID application has been submitted successfully.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  APPLICATION DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Applicant Name  :  {name}
  ECI Number      :  {eci}
  Status          :  Under Review

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Please keep your ECI Number safe — you will need it to track
the status of your application.

✨ Your Vote Makes All the Difference in the World. ✨

Thank you for registering as a voter. Every vote counts and
your participation strengthens our democracy.

Warm regards,
Election Commission of India
Voter Management System Portal
"""
    msg            = MIMEText(body)
    msg["Subject"] = f"✅ Voter ID Application Confirmed — {eci}"
    msg["From"]    = SMTP_CONFIG["sender_email"]
    msg["To"]      = to_email

    with smtplib.SMTP(SMTP_CONFIG["smtp_host"], SMTP_CONFIG["smtp_port"]) as server:
        server.starttls()
        server.login(SMTP_CONFIG["sender_email"], SMTP_CONFIG["sender_password"])
        server.sendmail(SMTP_CONFIG["sender_email"], to_email, msg.as_string())


# ──────────────────────────── IMAGE TO BYTES ─────────────────────────
def image_to_bytes(path, size):
    """Convert image file to JPEG bytes for LONGBLOB storage."""
    img = Image.open(path).convert("RGB").resize(size, Image.LANCZOS)
    buf = BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return buf.getvalue()


# ══════════════════════════════════════════════════════════════════════
#                         MAIN UI FUNCTION
# ══════════════════════════════════════════════════════════════════════
def open_apply_voter_page(parent):

    win = tk.Toplevel(parent)
    win.title("Apply for New Voter ID — VMS")
    win.state("zoomed")
    win.config(bg=C["bg"])

    _otp_store = {"code": None, "verified": False}

    # ── HEADER ──────────────────────────────────────────────────────
    header = tk.Frame(win, bg=C["header_bg"], height=66)
    header.pack(fill="x")
    header.pack_propagate(False)

    # Indian tricolour left strip
    strip = tk.Frame(header, width=6)
    strip.pack(side="left", fill="y")
    for colour in ("#FF9933", "#FFFFFF", "#138808"):
        tk.Frame(strip, bg=colour, height=22, width=6).pack(fill="x")

    tk.Label(header, text="🗳  Voter Management System — New Voter Registration",
             bg=C["header_bg"], fg=C["header_fg"],
             font=F_HEAD).pack(side="left", padx=16, pady=14)

    tk.Label(header, text="Election Commission of India",
             bg=C["header_bg"], fg="#c8dff5",
             font=F_SMALL).pack(side="left")

    tk.Button(header, text="⬅  Back",
              command=win.destroy,
              bg="#ffffff", fg=C["accent1"],
              font=F_BTN, relief="flat",
              padx=12, pady=6, cursor="hand2").pack(side="right", padx=20, pady=16)

    # ── SCROLLABLE BODY ──────────────────────────────────────────────
    body   = tk.Frame(win, bg=C["bg"])
    body.pack(fill="both", expand=True)

    canvas = tk.Canvas(body, bg=C["bg"], highlightthickness=0)
    vbar   = tk.Scrollbar(body, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=vbar.set)

    inner  = tk.Frame(canvas, bg=C["bg"])
    inner.bind("<Configure>",
               lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=inner, anchor="n")
    canvas.pack(side="left", fill="both", expand=True)
    vbar.pack(side="right", fill="y")

    win.bind("<MouseWheel>",
             lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

    # ── MAIN CARD ────────────────────────────────────────────────────
    card = tk.Frame(inner, bg=C["panel"],
                    highlightbackground=C["border"], highlightthickness=1)
    card.pack(pady=24, padx=50, fill="x")

    # Card title bar
    tbar = tk.Frame(card, bg=C["accent1"], height=46)
    tbar.pack(fill="x")
    tbar.pack_propagate(False)
    tk.Label(tbar, text="  📋  New Voter Registration Form  —  Form 6",
             bg=C["accent1"], fg="white",
             font=("Segoe UI", 13, "bold")).pack(side="left", pady=10)
    tk.Label(tbar, text="Fields marked * are mandatory   ",
             bg=C["accent1"], fg="#c8dff5",
             font=F_SMALL).pack(side="right")

    # ── GRID ────────────────────────────────────────────────────────
    grid = tk.Frame(card, bg=C["panel"])
    grid.pack(fill="both", expand=True, padx=8, pady=8)
    for i in range(5):
        grid.columnconfigure(i, weight=1)

    entries = {}

    # ── SECTION HEADER ───────────────────────────────────────────────
    def sec(text, row):
        f = tk.Frame(grid, bg=C["section_bg"],
                     highlightbackground=C["border"], highlightthickness=1)
        f.grid(row=row, column=0, columnspan=5,
               sticky="ew", padx=16, pady=(14, 2))
        tk.Label(f, text=f"  {text}",
                 bg=C["section_bg"], fg=C["section_fg"],
                 font=F_SEC).pack(side="left", pady=5)

    # ── FIELD BUILDER ────────────────────────────────────────────────
    def field(label, key, row, col, width=26,
              is_combo=False, vals=None, placeholder=""):
        wrap = tk.Frame(grid, bg=C["panel"])
        wrap.grid(row=row, column=col, padx=(16, 6), pady=5, sticky="nw")

        tk.Label(wrap, text=label,
                 bg=C["panel"], fg=C["subtext"],
                 font=F_LBL).pack(anchor="w")

        if is_combo:
            style = ttk.Style()
            style.theme_use("clam")
            style.configure("Light.TCombobox",
                             fieldbackground=C["entry_bg"],
                             background=C["entry_bg"],
                             foreground=C["text"],
                             bordercolor=C["border"])
            w = ttk.Combobox(wrap, values=vals, width=width-2,
                             font=F_ENTRY, style="Light.TCombobox",
                             state="readonly")
        else:
            w = tk.Entry(wrap, width=width, font=F_ENTRY,
                         bg=C["entry_bg"], fg=C["text"],
                         relief="solid", bd=1,
                         highlightthickness=1,
                         highlightbackground=C["border"],
                         highlightcolor=C["accent1"],
                         insertbackground=C["accent1"])
            if placeholder:
                w.insert(0, placeholder)
                w.config(fg=C["subtext"])
                def on_in(e, ww=w, ph=placeholder):
                    if ww.get() == ph:
                        ww.delete(0, tk.END)
                        ww.config(fg=C["text"])
                def on_out(e, ww=w, ph=placeholder):
                    if not ww.get():
                        ww.insert(0, ph)
                        ww.config(fg=C["subtext"])
                w.bind("<FocusIn>",  on_in)
                w.bind("<FocusOut>", on_out)
        w.pack(anchor="w")
        entries[key] = w
        return w

    # ── PERSONAL INFO ────────────────────────────────────────────────
    sec("👤  Personal Information", 0)
    field("First Name *",     "first_name",  1, 0)
    field("Last Name *",      "last_name",   1, 1)
    field("Father's Name *",  "father_name", 2, 0)
    field("Date of Birth *",  "dob",         2, 1, placeholder="DD/MM/YYYY")
    field("Gender *",         "gender",      3, 0,
          is_combo=True, vals=["Male", "Female", "Other"])
    field("Mobile Number *",  "mobile",      3, 1, placeholder="10-digit number")
    field("Email ID *",       "email",       4, 0, width=30)
    field("Aadhaar Number *", "aadhar",      4, 1, placeholder="12-digit number")

    # ── ADDRESS ──────────────────────────────────────────────────────
    sec("🏠  Address Details", 5)
    field("House / Flat No *", "house",       6, 0)
    field("Street / Area *",   "street",      6, 1)
    field("Village / Town *",  "village",     7, 0)
    field("Post Office *",     "post_office", 7, 1)
    field("District *",        "district",    8, 0)
    field("PIN Code *",        "pin",         8, 1, placeholder="6-digit PIN")
    field("State *",           "state",       9, 0)

    # ── RIGHT PANEL — Photo & Signature ─────────────────────────────
    rp = tk.Frame(grid, bg=C["card"],
                  highlightbackground=C["border"], highlightthickness=1)
    rp.grid(row=1, column=4, rowspan=9, padx=(8, 16), pady=6, sticky="n")

    _photo_bytes = [None]
    _sign_bytes  = [None]

    def img_slot(parent, title, w, h):
        tk.Label(parent, text=title,
                 bg=C["card"], fg=C["accent1"],
                 font=F_LBL).pack(pady=(12, 2))
        fr = tk.Frame(parent, width=w, height=h,
                      bg="#eef2f7", relief="groove", bd=1)
        fr.pack(padx=12)
        fr.pack_propagate(False)
        lbl = tk.Label(fr, text="No file selected",
                       bg="#eef2f7", fg=C["subtext"], font=F_SMALL)
        lbl.pack(expand=True)
        return lbl

    photo_lbl = img_slot(rp, "Applicant Photo",  182, 195)
    sign_lbl  = img_slot(rp, "Signature",         182,  78)

    def rp_btn(text, color, cmd):
        tk.Button(rp, text=text, bg=color, fg="white",
                  font=F_BTN, relief="flat",
                  padx=8, pady=5, cursor="hand2",
                  activebackground=C["text"],
                  command=cmd).pack(fill="x", padx=12, pady=4)

    def upload_photo():
        f = filedialog.askopenfilename(
            filetypes=[("Image Files", "*.jpg *.jpeg *.png")])
        if not f:
            return
        raw = image_to_bytes(f, (182, 195))
        _photo_bytes[0] = raw
        img = Image.open(BytesIO(raw))
        ph  = ImageTk.PhotoImage(img)
        photo_lbl.config(image=ph, text="")
        photo_lbl.image = ph

    def upload_sign():
        f = filedialog.askopenfilename(
            filetypes=[("Image Files", "*.jpg *.jpeg *.png")])
        if not f:
            return
        raw = image_to_bytes(f, (182, 78))
        _sign_bytes[0] = raw
        img = Image.open(BytesIO(raw))
        sg  = ImageTk.PhotoImage(img)
        sign_lbl.config(image=sg, text="")
        sign_lbl.image = sg

    rp_btn("⬆  Upload Photo",     C["accent1"], upload_photo)
    rp_btn("⬆  Upload Signature", "#7c3aed",    upload_sign)
    tk.Frame(rp, bg=C["card"], height=8).pack()

    # ── OTP SECTION ──────────────────────────────────────────────────
    sec("📧  Email OTP Verification", 10)

    otp_frame  = tk.Frame(grid, bg=C["panel"])
    otp_frame.grid(row=11, column=0, columnspan=4, sticky="w", padx=16, pady=8)

    otp_var    = tk.StringVar()
    status_var = tk.StringVar(value="")

    def _bg_send():
        email_val = entries["email"].get().strip()
        otp = str(random.randint(100000, 999999))
        _otp_store["code"]     = otp
        _otp_store["verified"] = False
        try:
            send_otp_email(email_val, otp)
            status_var.set(f"✔  OTP sent to {email_val}")
        except Exception as ex:
            status_var.set("⚠  Email failed — see popup for OTP")
            messagebox.showwarning(
                "SMTP Error",
                f"Could not send email:\n{ex}\n\n"
                f"[DEMO MODE] OTP = {otp}"
            )

    def send_otp():
        email_val = entries["email"].get().strip()
        if not re.match(r"^[\w.\-]+@[\w.\-]+\.\w{2,}$", email_val):
            messagebox.showerror("Error", "Enter a valid Email ID first.")
            return
        status_var.set("Sending OTP, please wait…")
        threading.Thread(target=_bg_send, daemon=True).start()

    def verify_otp():
        entered = otp_var.get().strip()
        if not _otp_store["code"]:
            messagebox.showwarning("Warning", "Please send OTP first.")
            return
        if entered == _otp_store["code"]:
            _otp_store["verified"] = True
            status_var.set("✔  Email verified successfully!")
        else:
            status_var.set("✘  Incorrect OTP — try again")

    tk.Button(otp_frame, text="Send OTP",
              bg=C["btn_otp"], fg="white", font=F_BTN,
              relief="flat", padx=12, pady=5, cursor="hand2",
              command=send_otp).pack(side="left", padx=(0, 8))

    tk.Entry(otp_frame, textvariable=otp_var, width=12,
             font=F_ENTRY, bg=C["entry_bg"], fg=C["text"],
             relief="solid", bd=1).pack(side="left", padx=(0, 8))

    tk.Button(otp_frame, text="Verify OTP",
              bg=C["btn_verify"], fg="white", font=F_BTN,
              relief="flat", padx=12, pady=5, cursor="hand2",
              command=verify_otp).pack(side="left")

    tk.Label(otp_frame, textvariable=status_var,
             bg=C["panel"], fg=C["ok_green"],
             font=F_LBL).pack(side="left", padx=14)

    # ── VALIDATION ───────────────────────────────────────────────────
    PLACEHOLDERS = {"dob": "DD/MM/YYYY", "mobile": "10-digit number",
                    "aadhar": "12-digit number", "pin": "6-digit PIN"}

    def gv(key):
        w   = entries[key]
        val = w.get().strip() if hasattr(w, "get") else ""
        return "" if val == PLACEHOLDERS.get(key, "") else val

    def validate():
        errs = []
        if not re.match(r"^[A-Za-z ]+$", gv("first_name")):
            errs.append("First Name — letters only")
        if not re.match(r"^[A-Za-z ]+$", gv("last_name")):
            errs.append("Last Name — letters only")
        if not gv("father_name"):
            errs.append("Father's Name is required")
        if not re.match(r"^\d{2}/\d{2}/\d{4}$", gv("dob")):
            errs.append("Date of Birth — use DD/MM/YYYY")
        if not gv("gender"):
            errs.append("Gender is required")
        if not re.match(r"^[0-9]{10}$", gv("mobile")):
            errs.append("Mobile — must be 10 digits")
        if not re.match(r"^[\w.\-]+@[\w.\-]+\.\w{2,}$", gv("email")):
            errs.append("Email ID — invalid format")
        if not re.match(r"^[0-9]{12}$", gv("aadhar")):
            errs.append("Aadhaar — must be 12 digits")
        for k, lbl in [("house","House No"),("street","Street"),
                        ("village","Village/Town"),("post_office","Post Office"),
                        ("district","District"),("state","State")]:
            if not gv(k):
                errs.append(f"{lbl} is required")
        if not re.match(r"^[0-9]{6}$", gv("pin")):
            errs.append("PIN Code — must be 6 digits")
        if not _otp_store["verified"]:
            errs.append("Email OTP must be verified before submitting")
        if errs:
            messagebox.showerror("Please fix the following",
                                 "\n".join(f"  • {e}" for e in errs))
            return False
        return True

    # ── SUBMIT ───────────────────────────────────────────────────────
    def submit():
        if not validate():
            return

        # Convert DD/MM/YYYY → YYYY-MM-DD for MySQL DATE column
        try:
            d, m, y = gv("dob").split("/")
            dob_sql = f"{y}-{m.zfill(2)}-{d.zfill(2)}"
        except ValueError:
            messagebox.showerror("Error", "Invalid date — use DD/MM/YYYY.")
            return

        data = {
            "first_name":  gv("first_name"),
            "last_name":   gv("last_name"),
            "father_name": gv("father_name"),
            "dob":         dob_sql,
            "gender":      gv("gender"),
            "mobile":      gv("mobile"),
            "email":       gv("email"),
            "aadhar":      gv("aadhar"),
            "house":       gv("house"),
            "street":      gv("street"),
            "village":     gv("village"),
            "post_office": gv("post_office"),
            "district":    gv("district"),
            "pin":         gv("pin"),
            "state":       gv("state"),
            "photo":       _photo_bytes[0],
            "signature":   _sign_bytes[0],
        }

        try:
            eci = save_voter(data)
            full_name = f"{data['first_name']} {data['last_name']}"

            # Send confirmation email in background
            def _send_conf():
                try:
                    send_confirmation_email(data["email"], full_name, eci)
                except Exception:
                    pass  # silently ignore if email fails after DB save

            threading.Thread(target=_send_conf, daemon=True).start()

            # Small non-blocking toast instead of the old popup
            toast = tk.Toplevel(win)
            toast.title("")
            toast.resizable(False, False)
            toast.config(bg="#ffffff")
            toast.grab_set()

            # Centre on screen
            toast.update_idletasks()
            tw, th = 440, 210
            sx = win.winfo_x() + (win.winfo_width()  - tw) // 2
            sy = win.winfo_y() + (win.winfo_height() - th) // 2
            toast.geometry(f"{tw}x{th}+{sx}+{sy}")

            tk.Frame(toast, bg=C["accent2"], height=6).pack(fill="x")

            tk.Label(toast, text="✔  Application Submitted Successfully!",
                     bg="#ffffff", fg=C["accent2"],
                     font=("Segoe UI", 13, "bold")).pack(pady=(16, 4))

            tk.Label(toast, text=f"Your ECI Number:   {eci}",
                     bg="#ffffff", fg=C["text"],
                     font=("Segoe UI", 11, "bold")).pack()

            tk.Label(toast,
                     text=f"A confirmation has been sent to\n{data['email']}",
                     bg="#ffffff", fg=C["subtext"],
                     font=("Segoe UI", 9)).pack(pady=(6, 4))

            tk.Label(toast,
                     text="✨  Your Vote Makes All the Difference in the World  ✨",
                     bg="#ffffff", fg=C["accent1"],
                     font=("Segoe UI", 9, "italic")).pack(pady=(2, 12))

            tk.Button(toast, text="  OK  ",
                      bg=C["btn_submit"], fg="white",
                      font=("Segoe UI", 10, "bold"),
                      relief="flat", padx=16, pady=6,
                      cursor="hand2",
                      command=toast.destroy).pack()

            tk.Frame(toast, bg=C["section_bg"], height=6).pack(fill="x", pady=(12, 0))

            clear()
        except Exception as ex:
            messagebox.showerror("Database Error", str(ex))

    # ── CLEAR ────────────────────────────────────────────────────────
    def clear():
        for key, w in entries.items():
            if isinstance(w, ttk.Combobox):
                w.set("")
            elif isinstance(w, tk.Entry):
                w.delete(0, tk.END)
                if key in PLACEHOLDERS:
                    w.insert(0, PLACEHOLDERS[key])
                    w.config(fg=C["subtext"])
        otp_var.set("")
        status_var.set("")
        _otp_store["code"]     = None
        _otp_store["verified"] = False
        _photo_bytes[0] = None
        _sign_bytes[0]  = None
        photo_lbl.config(image="", text="No file selected")
        sign_lbl.config(image="",  text="No file selected")
        photo_lbl.image = None
        sign_lbl.image  = None

    # ── ACTION BUTTONS ───────────────────────────────────────────────
    btn_bar = tk.Frame(card, bg=C["panel"])
    btn_bar.pack(pady=18)

    tk.Button(btn_bar, text="  ✔  Submit Application  ",
              bg=C["btn_submit"], fg="white",
              font=("Segoe UI", 12, "bold"),
              relief="flat", padx=20, pady=10,
              cursor="hand2", command=submit).pack(side="left", padx=12)

    tk.Button(btn_bar, text="  ↺  Clear Form  ",
              bg=C["btn_clear"], fg="white",
              font=("Segoe UI", 12, "bold"),
              relief="flat", padx=20, pady=10,
              cursor="hand2", command=clear).pack(side="left", padx=12)

    # ── FOOTER ───────────────────────────────────────────────────────
    footer = tk.Frame(win, bg=C["section_bg"], height=30)
    footer.pack(fill="x", side="bottom")
    footer.pack_propagate(False)
    tk.Label(footer,
             text="Election Commission of India  |  Voter Management System  |  Secure & Confidential",
             bg=C["section_bg"], fg=C["subtext"],
             font=F_SMALL).pack(pady=8)


# ── Standalone test launcher ──────────────────────────────────────────
if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    open_apply_voter_page(root)
    root.mainloop()