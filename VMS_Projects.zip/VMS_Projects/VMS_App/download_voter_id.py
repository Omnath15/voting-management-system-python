import tkinter as tk
from tkinter import messagebox, filedialog
from PIL import Image, ImageDraw, ImageFont
import pymysql
import random, smtplib, ssl
from email.message import EmailMessage
import qrcode
import os

from reportlab.platypus import SimpleDocTemplate, Image as RLImage
from reportlab.lib.pagesizes import letter

# -------- EMAIL CONFIG --------
SENDER_EMAIL = "om18niit@gmail.com"
SENDER_PASSWORD = "gmwgfyotjrarpakm"

# -------- MAIN PAGE --------
def open_download_page(parent):

    win = tk.Toplevel(parent)
    win.title("Download Voter ID")
    win.geometry("500x450")
    win.config(bg="#ecf0f1")

    tk.Label(win, text="📥 Download Voter ID",
             font=("Segoe UI", 20, "bold"),
             bg="#ecf0f1").pack(pady=20)

    tk.Label(win, text="Mobile").pack()
    mobile = tk.Entry(win)
    mobile.pack()

    tk.Label(win, text="Email").pack()
    email = tk.Entry(win)
    email.pack()

    otp_var = tk.StringVar()
    generated_otp = {"code": ""}

    # -------- OTP --------
    def send_otp():
        otp = str(random.randint(100000, 999999))
        generated_otp["code"] = otp

        try:
            msg = EmailMessage()
            msg.set_content(f"Your OTP is: {otp}")
            msg["Subject"] = "OTP Verification"
            msg["From"] = SENDER_EMAIL
            msg["To"] = email.get()

            context = ssl.create_default_context()
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
                server.login(SENDER_EMAIL, SENDER_PASSWORD)
                server.send_message(msg)

            messagebox.showinfo("Success", "OTP sent")

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def verify_otp():
        if otp_var.get() == generated_otp["code"]:
            messagebox.showinfo("Success", "OTP Verified")
        else:
            messagebox.showerror("Error", "Invalid OTP")

    tk.Button(win, text="Send OTP", command=send_otp).pack(pady=5)
    tk.Entry(win, textvariable=otp_var).pack()
    tk.Button(win, text="Verify OTP", command=verify_otp).pack(pady=5)

    # -------- FETCH DATA --------
    def fetch_data():
        conn = pymysql.connect(host="localhost", user="root", password="root", database="VMS")
        cur = conn.cursor()

        cur.execute("""
        SELECT first_name,last_name,father_name,dob,gender,eci_number,photo_path
        FROM voter_registration WHERE mobile=%s AND email=%s
        """, (mobile.get(), email.get()))

        data = cur.fetchone()
        conn.close()
        return data

    # -------- PRO CARD DESIGN --------
    def generate_card(data):

        from PIL import ImageFont
        import barcode
        from barcode.writer import ImageWriter
    
        name = data[0] + " " + data[1]
        father = data[2]
        dob = str(data[3])
        gender = data[4]
        eci = data[5]
        photo_path = data[6]
    
        # 👉 If you add address later in DB:
        address = "India"   # Replace with real fields if available
    
        # -------- CARD BASE --------
        width, height = 860, 540
        base = Image.new("RGB", (width, height), "#dcdcdc")  # shadow bg
        img = Image.new("RGB", (820, 500), "white")
    
        base.paste(img, (20, 20))  # shadow effect
        draw = ImageDraw.Draw(base)
    
        # -------- COLORS --------
        saffron = "#FF9933"
        green = "#138808"
        navy = "#000080"
    
        # -------- TRICOLOR HEADER --------
        draw.rectangle((20, 20, 840, 50), fill=saffron)
        draw.rectangle((20, 50, 840, 80), fill="white")
        draw.rectangle((20, 80, 840, 110), fill=green)
    
        # -------- TITLE --------
        draw.text((250, 55), "ELECTION COMMISSION OF INDIA", fill="black")
        draw.text((300, 120), "VOTER IDENTITY CARD", fill=navy)
    
        # -------- ASHOKA CHAKRA (DRAWN CIRCLE) --------
        #draw.ellipse((400, 30, 440, 70), outline=navy, width=2)
    
        # -------- PHOTO --------
        if photo_path and os.path.exists(photo_path):
            photo = Image.open(photo_path).resize((160, 190))
            base.paste(photo, (60, 170))
    
            draw.rectangle((60, 170, 220, 360), outline="black", width=2)
    
        # -------- TEXT --------
        x = 250
        y = 180
        gap = 38
    
        draw.text((x, y), f"Name      : {name}", fill="black")
        draw.text((x, y+gap), f"Father    : {father}", fill="black")
        draw.text((x, y+gap*2), f"DOB       : {dob}", fill="black")
        draw.text((x, y+gap*3), f"Gender    : {gender}", fill="black")
    
        # -------- ADDRESS --------
        draw.text((x, y+gap*4), f"Address   : {address}", fill="black")
    
        # -------- ECI BOX --------
        draw.rectangle((x, y+gap*5, x+380, y+gap*5+35), outline=navy, width=2)
        draw.text((x+10, y+gap*5+5), f"EPIC NO: {eci}", fill=navy)
    
        # -------- BARCODE --------
        try:
            CODE128 = barcode.get_barcode_class('code128')
            barcode_obj = CODE128(eci, writer=ImageWriter())
            barcode_path = "temp_barcode"
            barcode_obj.save(barcode_path)
    
            barcode_img = Image.open(barcode_path + ".png").resize((300, 80))
            base.paste(barcode_img, (500, 360))
    
        except:
            draw.text((500, 380), f"{eci}", fill="black")
    
        # -------- FOOTER --------
        draw.text((300, 500), "Government of India", fill="gray")
    
        return base
    # -------- PDF GENERATE --------
    def save_as_pdf(image, file_path):
        temp_img = "temp_card.png"
        image.save(temp_img)

        pdf = SimpleDocTemplate(file_path, pagesize=letter)
        elements = [RLImage(temp_img, width=400, height=250)]
        pdf.build(elements)

        os.remove(temp_img)

    # -------- EMAIL SEND --------
    def send_email(file_path):
        try:
            msg = EmailMessage()
            msg["Subject"] = "Your Voter ID"
            msg["From"] = SENDER_EMAIL
            msg["To"] = email.get()
            msg.set_content("Attached is your Voter ID PDF")

            with open(file_path, "rb") as f:
                msg.add_attachment(f.read(), maintype="application", subtype="pdf", filename="VoterID.pdf")

            context = ssl.create_default_context()
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
                server.login(SENDER_EMAIL, SENDER_PASSWORD)
                server.send_message(msg)

        except Exception as e:
            messagebox.showerror("Email Error", str(e))

    # -------- DOWNLOAD --------
    def download():

        if otp_var.get() != generated_otp["code"]:
            messagebox.showerror("Error", "Verify OTP first")
            return

        data = fetch_data()
        if not data:
            messagebox.showerror("Error", "User not found")
            return

        img = generate_card(data)

        file = filedialog.asksaveasfilename(defaultextension=".pdf",
                                            filetypes=[("PDF Files", "*.pdf")])
        if not file:
            return

        save_as_pdf(img, file)
        send_email(file)

        os.startfile(file)
        messagebox.showinfo("Success", "PDF Downloaded & Sent")

    # -------- PRINT --------
    def print_card():
        data = fetch_data()
        if not data:
            messagebox.showerror("Error", "Fetch data first")
            return

        img = generate_card(data)
        temp = "temp_print.png"
        img.save(temp)

        os.startfile(temp, "print")

    tk.Button(win, text="Download PDF", bg="#16a085", fg="white",
              command=download).pack(pady=10)

    tk.Button(win, text="Print Card", bg="#34495e", fg="white",
              command=print_card).pack()