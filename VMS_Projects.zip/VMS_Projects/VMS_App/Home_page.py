import tkinter as tk

# ------------------ DASHBOARD ------------------
def open_dashboard():
    dash = tk.Tk()
    dash.title("VMS Dashboard")
    dash.state("zoomed")
    dash.config(bg="#f4f6f7")

    # ---------------- HEADER ----------------
    header = tk.Frame(dash, bg="#2C3E50", height=70)
    header.pack(fill="x")

    tk.Label(header, text="Voting Management System",
             bg="#2C3E50", fg="white",
             font=("Segoe UI", 22, "bold")).pack(side="left", padx=20)

    tk.Label(header, text=f"Welcome",#{user} here user name call
             bg="#2C3E50", fg="white",
             font=("Segoe UI", 12)).pack(side="right", padx=20)

    # ---------------- MAIN AREA ----------------
    main = tk.Frame(dash, bg="#f4f6f7")
    main.pack(expand=True, fill="both", padx=40, pady=40)

    tk.Label(main, text="Dashboard",
             font=("Segoe UI", 28, "bold"),
             bg="#f4f6f7", fg="#2C3E50").pack(anchor="center", pady=10)

    # ---------------- MENU GRID ----------------
    grid = tk.Frame(main, bg="#f4f6f7")
    grid.pack(pady=30)

    def create_card(text, color, row, col):
        card = tk.Frame(grid, bg=color, width=250, height=150, cursor="hand2")
        card.grid(row=row, column=col, padx=20, pady=20)
        card.grid_propagate(False)

        label = tk.Label(card, text=text, bg=color, fg="white",
                         font=("Segoe UI", 14, "bold"), wraplength=200)
        label.pack(expand=True)

        # Hover effect
        def on_enter(e):
            card.config(bg="#1abc9c")

        def on_leave(e):
            card.config(bg=color)

        card.bind("<Enter>", on_enter)
        card.bind("<Leave>", on_leave)
        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)
        card.bind("<Enter>", on_enter)
        card.bind("<Leave>", on_leave)
        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)
        card.bind("<Enter>", on_enter)
        card.bind("<Leave>", on_leave)
        label.bind("<Enter>", on_enter)
        label.bind("<Leave>", on_leave)

    # ---------------- 6 MENU OPTIONS ----------------
    create_card("🆔 Apply New Voter ID", "#16a085", 0, 0)
    create_card("📄 Check Application Status", "#2980b9", 0, 1)
    create_card("🗳️ Vote Now", "#8e44ad", 0, 2)

    create_card("👤 Profile", "#d35400", 1, 0)
    create_card("📊 Results / Reports", "#c0392b", 1, 1)
    create_card("🚪 Logout", "#2c3e50", 1, 2)

    dash.mainloop()
open_dashboard()