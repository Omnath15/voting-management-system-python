import tkinter as tk 
def Home_page(user):
    dash=tk.Toplevel()
    dash.geometry('500x500')
    dash.configure(bg='yellow')
    dash.title('Home page')
    dash.mainloop()
#Home_page()

def About_page():
    Abs=tk.Toplevel()
    Abs.geometry('500x500')
    Abs.configure(bg='cyan')
    Abs.title('About page')
    Abs.mainloop()