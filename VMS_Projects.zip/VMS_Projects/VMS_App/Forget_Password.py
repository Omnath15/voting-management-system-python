import tkinter as tk
from tkinter import messagebox
import random
import smtplib
import pymysql
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# ------------------ DATABASE ------------------
def db_connect():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",   # change if needed
        database="VMS"
    )

# ------------------ GLOBAL OTP ------------------
generated_otp = ""

# ------------------ SEND OTP ------------------
def send_otp():
    global generated_otp
    email = email_entry.get()

    if email == "":
        messagebox.showerror("Error", "Enter Email First")
        return

    generated_otp = str(random.randint(100000, 999999))

    sender_email = "om18niit@gmail.com"
    app_password = "gmwgfyotjrarpakm"

    try:
        msg = MIMEMultipart()
        msg["From"] = sender_email
        msg["To"] = email
        msg["Subject"] = "🔐 Password Reset OTP"

        html = f"""
        <html>
        <body style="font-family:Arial; background:#f4f4f4; padding:20px;">
            <div style="background:white; padding:20px; border-radius:10px; text-align:center;">
                <h2>Password Reset - VMS</h2>
                <p>Your OTP is:</p>
                <h1 style="color:#27AE60;">{generated_otp}</h1>
                <p style="color:red;">Do not share this OTP</p>
            </div>
        </body>
        </html>
        """

        msg.attach(MIMEText(html, "html"))

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()

        messagebox.showinfo("Success", "OTP sent successfully!")

    except Exception as e:
        messagebox.showerror("Error", str(e))

# ------------------ RESET PASSWORD ------------------
def reset_password():
    contact = contact_entry.get()
    email = email_entry.get()
    user_id = user_entry.get()
    otp = otp_entry.get()
    new_pass = new_pass_entry.get()
    confirm_pass = confirm_pass_entry.get()

    if not all([contact, email, user_id, otp, new_pass, confirm_pass]):
        messagebox.showerror("Error", "All fields required")
        return

    if otp != generated_otp:
        messagebox.showerror("Error", "Invalid OTP")
        return

    if new_pass != confirm_pass:
        messagebox.showerror("Error", "Passwords do not match")
        return

    try:
        conn = db_connect()
        cursor = conn.cursor()

        cursor.execute(
            "SELECT * FROM Login WHERE Contact_Number=%s AND Email=%s AND User_Id=%s",
            (contact, email, user_id)
        )

        if cursor.fetchone():
            cursor.execute(
                "UPDATE Login SET Password=%s WHERE Contact_Number=%s",
                (new_pass, contact)
            )
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Password Updated Successfully")

            send_success_email(email, user_id)

        else:
            messagebox.showerror("Error", "User not found")

    except Exception as e:
        messagebox.showerror("Database Error", str(e))

# ------------------ SUCCESS EMAIL ------------------
def send_success_email(email, user_id):
    sender_email = "om18niit@gmail.com"
    app_password = "gmwgfyotjrarpakm"

    try:
        msg = MIMEMultipart()
        msg["From"] = sender_email
        msg["To"] = email
        msg["Subject"] = "✅ Password Updated Successfully"

        html = f"""
        <html>
        <body style="font-family:Arial;">
            <h2>Password Updated</h2>
            <p>Dear {user_id},</p>
            <p>Your password has been successfully updated.</p>
            <p>If this was not you, contact support immediately.</p>
        </body>
        </html>
        """

        msg.attach(MIMEText(html, "html"))

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()

    except Exception as e:
        print(e)

# ------------------ UI DESIGN ------------------
def open_forgot_password(parent):
    '''global current_window
    if current_window:
        current_window.destroy()'''
    win = tk.Toplevel(parent)
    win.title("Forgot Password - VMS")
    win.geometry("450x600")
    win.configure(bg="#1C2833")

    tk.Label(win, text="Forgot Password",
             font=("Arial", 20, "bold"),
             bg="#1C2833", fg="white").pack(pady=15)

    def create_entry(label):
        tk.Label(win, text=label, bg="#1C2833", fg="white").pack()
        entry = tk.Entry(win, width=30, font=("Arial", 12))
        entry.pack(pady=5, ipady=5)
        return entry

    global contact_entry, email_entry, user_entry
    global otp_entry, new_pass_entry, confirm_pass_entry

    contact_entry = create_entry("Contact Number")
    email_entry = create_entry("Email")
    user_entry = create_entry("User ID")

    tk.Button(win, text="Send OTP",
              bg="#27AE60", fg="white",
              command=send_otp).pack(pady=10)

    otp_entry = create_entry("Enter OTP")

    new_pass_entry = create_entry("New Password")
    new_pass_entry.config(show="*")

    confirm_pass_entry = create_entry("Confirm Password")
    confirm_pass_entry.config(show="*")

    tk.Button(win, text="Reset Password",
              bg="#2980B9", fg="white",
              command=reset_password).pack(pady=20)
'''root = tk.Tk()
root.title("Forgot Password - VMS")
root.geometry("450x600")
root.configure(bg="#1C2833")

tk.Label(root, text="Forgot Password",
         font=("Arial", 20, "bold"),
         bg="#1C2833", fg="white").pack(pady=15)

def create_entry(label):
    tk.Label(root, text=label, bg="#1C2833", fg="white").pack()
    entry = tk.Entry(root, width=30, font=("Arial", 12))
    entry.pack(pady=5, ipady=5)
    return entry

contact_entry = create_entry("Contact Number")
email_entry = create_entry("Email")
user_entry = create_entry("User ID")

tk.Button(root, text="Send OTP",
          bg="#27AE60", fg="white",
          width=20,
          command=send_otp).pack(pady=10)

otp_entry = create_entry("Enter OTP")

new_pass_entry = create_entry("New Password")
new_pass_entry.config(show="*")

confirm_pass_entry = create_entry("Confirm Password")
confirm_pass_entry.config(show="*")

tk.Button(root, text="Reset Password",
          bg="#2980B9", fg="white",
          width=20,
          command=reset_password).pack(pady=20)'''

#root.mainloop()