import tkinter as tk
from tkinter import messagebox
import pymysql
import matplotlib.pyplot as plt


def open_result_page(parent):

    win = tk.Toplevel(parent)
    win.title("Election Results")
    win.geometry("600x500")
    win.config(bg="#ecf0f1")

    tk.Label(win, text="📊 Election Results",
             font=("Segoe UI", 20, "bold"),
             bg="#ecf0f1").pack(pady=20)

    result_frame = tk.Frame(win, bg="#ecf0f1")
    result_frame.pack(pady=20)

    # -------- FETCH RESULTS --------
    def fetch_results():
        conn = pymysql.connect(host="localhost", user="root", password="root", database="VMS")
        cur = conn.cursor()

        cur.execute("""
        SELECT party, COUNT(*) as total
        FROM votes
        GROUP BY party
        """)

        data = cur.fetchall()
        conn.close()
        return data

    # -------- SHOW RESULTS --------
    def show_results():

        for widget in result_frame.winfo_children():
            widget.destroy()

        data = fetch_results()

        if not data:
            messagebox.showwarning("No Data", "No votes found")
            return

        parties = []
        votes = []

        for party, count in data:
            parties.append(party)
            votes.append(count)

            tk.Label(result_frame,
                     text=f"{party} : {count} votes",
                     font=("Segoe UI", 12, "bold"),
                     bg="#ecf0f1").pack()

        # -------- WINNER --------
        max_votes = max(votes)
        winner = parties[votes.index(max_votes)]

        tk.Label(result_frame,
                 text=f"🏆 Winner: {winner}",
                 font=("Segoe UI", 16, "bold"),
                 fg="green",
                 bg="#ecf0f1").pack(pady=20)

        # -------- CHART --------
        plt.figure()
        plt.bar(parties, votes)
        plt.title("Election Results")
        plt.xlabel("Parties")
        plt.ylabel("Votes")
        plt.show()

    tk.Button(win, text="Show Results",
              bg="#27ae60", fg="white",
              font=("Segoe UI", 12, "bold"),
              command=show_results).pack(pady=10)