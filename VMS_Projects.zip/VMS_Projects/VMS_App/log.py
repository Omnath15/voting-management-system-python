import tkinter as tk
from tkinter import messagebox
import random
import string

# Function to generate captcha
def generate_captcha():
    captcha = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    label_captcha.config(text=captcha)
    return captcha

# Function to validate login
def sign_in():
    user_id = entry_userid.get()
    password = entry_password.get()
    captcha_input = entry_captcha.get()
    captcha_text = label_captcha.cget("text")

    if not user_id or not password or not captcha_input:
        messagebox.showwarning("Input Error", "All fields are required!")
        return

    if captcha_input != captcha_text:
        messagebox.showerror("Captcha Error", "Captcha does not match!")
        return

    # Example validation (replace with DB check)
    if user_id == "admin" and password == "12345":
        messagebox.showinfo("Login Success", f"Welcome {user_id}!")
    else:
        messagebox.showerror("Login Failed", "Invalid User ID or Password")

# Function for Sign Up
def sign_up():
    messagebox.showinfo("Sign Up", "Redirecting to Sign Up Page...")

# Function for Forget Password
def forget_password():
    messagebox.showinfo("Forget Password", "Password recovery process initiated...")

# Function to clear fields
def clear_fields():
    entry_userid.delete(0, tk.END)
    entry_password.delete(0, tk.END)
    entry_captcha.delete(0, tk.END)
    generate_captcha()

# Main window
root = tk.Tk()
root.title("Login Page")
root.geometry("400x350")
root.resizable(False, False)

# Frame for login
frame = tk.Frame(root, bg="#f0f0f0", bd=5, relief=tk.RIDGE)
frame.place(relx=0.5, rely=0.5, anchor="center", width=350, height=300)

# Heading
label_heading = tk.Label(frame, text="Login Page", font=("Arial", 16, "bold"), bg="#f0f0f0")
label_heading.pack(pady=10)

# User ID
label_userid = tk.Label(frame, text="User ID:", font=("Arial", 12), bg="#f0f0f0")
label_userid.pack()
entry_userid = tk.Entry(frame, width=30)
entry_userid.pack(pady=5)

# Password
label_password = tk.Label(frame, text="Password:", font=("Arial", 12), bg="#f0f0f0")
label_password.pack()
entry_password = tk.Entry(frame, width=30, show="*")
entry_password.pack(pady=5)

# Captcha
label_captcha_title = tk.Label(frame, text="Captcha:", font=("Arial", 12), bg="#f0f0f0")
label_captcha_title.pack()
label_captcha = tk.Label(frame, text="", font=("Arial", 14, "bold"), fg="blue", bg="#f0f0f0")
label_captcha.pack()
entry_captcha = tk.Entry(frame, width=30)
entry_captcha.pack(pady=5)

# Buttons
btn_frame = tk.Frame(frame, bg="#f0f0f0")
btn_frame.pack(pady=10)

btn_signin = tk.Button(btn_frame, text="Sign In", width=10, command=sign_in)
btn_signin.grid(row=0, column=0, padx=5)

btn_signup = tk.Button(btn_frame, text="Sign Up", width=10, command=sign_up)
btn_signup.grid(row=0, column=1, padx=5)

btn_forget = tk.Button(btn_frame, text="Forget Password", width=15, command=forget_password)
btn_forget.grid(row=1, column=0, columnspan=2, pady=5)

btn_clear = tk.Button(frame, text="Clear", width=10, command=clear_fields)
btn_clear.pack(pady=5)

# Generate initial captcha
generate_captcha()

# Run the application
root.mainloop()