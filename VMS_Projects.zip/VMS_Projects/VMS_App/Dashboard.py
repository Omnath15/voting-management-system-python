import tkinter as tk
from Apply_New_Voter_ID import open_apply_voter_page
from download_voter_id import open_download_page
from vote_page import open_vote_page
from result_page import open_result_page
from admin_panel import open_admin_panel
from update_voter import open_update_page
from tkinter import simpledialog, messagebox

# ------------------ DASHBOARD ------------------
def open_dashboard(user):
    dash = tk.Toplevel()
    dash.grab_set()
    dash.title("VMS Dashboard")
    dash.state("zoomed")
    dash.config(bg="#f4f6f7")
    def open_admin_secure():
        password = simpledialog.askstring("Admin Login", "Enter Admin Password:", show="*")
    
        if password == "admin123":   # 🔴 Change this password
            open_admin_panel(dash)
        else:
            messagebox.showerror("Access Denied", "Incorrect Password!")
    # ---------------- HEADER ----------------
    header = tk.Frame(dash, bg="#2C3E50", height=70)
    header.pack(fill="x")
    header.pack_propagate(False)

    tk.Label(header, text="🗳️ Voting Management System",
             bg="#2C3E50", fg="white",
             font=("Segoe UI", 22, "bold")).pack(side="left", padx=20, pady=15)

    tk.Label(header, text=f"👤 Welcome {user}",
             bg="#2C3E50", fg="#1abc9c",
             font=("Segoe UI", 12, "bold")).pack(side="right", padx=20)



    # ---------------- MAIN AREA ----------------
    main = tk.Frame(dash, bg="#f4f6f7")
    main.pack(expand=True, fill="both", padx=40, pady=40)




    tk.Label(main, text="Dashboard",
             font=("Segoe UI", 28, "bold"),
             bg="#f4f6f7", fg="#2C3E50").pack(anchor="center", pady=10)

    tk.Label(main, text="Select an option to continue",
             font=("Segoe UI", 12),
             bg="#f4f6f7", fg="gray").pack(anchor="center", pady=(0, 20))

    # ---------------- MENU GRID ----------------
    grid = tk.Frame(main, bg="#f4f6f7")
    grid.pack(pady=10)

    # ---------------- CARD CREATOR ----------------
    def create_card(text, color, row, col, command=None):
        # Outer shadow effect using a slightly larger dark frame
        shadow = tk.Frame(grid, bg="#cccccc", width=256, height=156)
        shadow.grid(row=row, column=col, padx=22, pady=22)
        shadow.grid_propagate(False)

        card = tk.Frame(shadow, bg=color, width=250, height=150, cursor="hand2")
        card.place(x=0, y=0, width=250, height=150)
        card.pack_propagate(False)

        label = tk.Label(card, text=text, bg=color, fg="white",
                         font=("Segoe UI", 14, "bold"), wraplength=200)
        label.place(relx=0.5, rely=0.5, anchor="center")

        # ---------------- HOVER EFFECT ----------------
        def on_enter(e):
            card.config(bg="#1abc9c")
            label.config(bg="#1abc9c")

        def on_leave(e):
            card.config(bg=color)
            label.config(bg=color)

        def on_click(e):
            if command:
                command()

        # Bind hover and click on both card and label
        for widget in (card, label):
            widget.bind("<Enter>", on_enter)
            widget.bind("<Leave>", on_leave)
            widget.bind("<Button-1>", on_click)

    # ---------------- LOGOUT FUNCTION ----------------
    def logout():
        dash.destroy()

    # ---------------- 6 MENU CARDS ----------------
    #create_card("🆔 Apply New\nVoter ID",        "#16a085", 0, 0)
    #create_card("🆔 Apply New\nVoter ID", "#16a085", 0, 0,command=lambda: open_apply_voter_page(dash))
    create_card("🆔 Apply New\nVoter ID", "#16a085", 0, 0,
            command=lambda: open_apply_voter_page(dash))
    create_card("📄 Update Voter ID",  "#2980b9", 0, 1,
                command=lambda: open_update_page(dash))
    
    create_card("🗳️ Vote Now",                   "#8e44ad", 0, 2,
                command=lambda: open_vote_page(dash))
    create_card("👤 Admin",                    "#d35400", 1, 0,
                #command=lambda: open_admin_panel(dash)
                command=open_admin_secure
                )
    create_card("📊 Results / Reports",          "#c0392b", 1, 1
                ,command=lambda: open_result_page(dash))
    #create_card("🚪 Dowmload VoterID",                     "#2c3e50", 1, 2, command=logout)
    create_card("📥 Download\nVoter ID", "#2c3e50", 1, 2,
                command=lambda: open_download_page(dash))
    # ---------------- FOOTER ----------------
    footer = tk.Frame(dash, bg="#2C3E50", height=35)
    footer.pack(fill="x", side="bottom")
    footer.pack_propagate(False)

    tk.Label(footer, text="© 2025 Voting Management System | All Rights Reserved",
             bg="#2C3E50", fg="gray",
             font=("Segoe UI", 9)).pack(pady=8)

    dash.mainloop()

# ------------------ RUN ------------------
#open_dashboard()