import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import re
import random
import smtplib
from email.mime.text import MIMEText
import mysql.connector
import os
import uuid  
    # --- DATABASE CONNECTION ---
def get_db_connection():
        return mysql.connector.connect(
            host="localhost",
            user="root",      # Your MySQL username
            password="root", # Your MySQL password
            database="VMS"
        )
SENDER_EMAIL = "om18niit@gmail.com"
APP_PASSWORD = "gmwgfyotjrarpakm"
    
generated_otp = ""
otp_verified = False
    
def open_apply_voter_page(parent):
        apply_win = tk.Toplevel(parent)
        apply_win.title("Apply New Voter ID")
        apply_win.state("zoomed")
        apply_win.config(bg="#ecf0f1")
        photo_path = ""
        sign_path = ""
        
        def generate_eci():
            letters = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=3))
            numbers = ''.join(random.choices('0123456789', k=7))
            return letters + numbers
        # ---------------- OTP FUNCTIONS ----------------
        def send_otp():
            global generated_otp
            user_email = email.get()
            if user_email == "":
                messagebox.showerror("Error", "Enter Email First")
                return
            generated_otp = str(random.randint(100000, 999999))
            try:
                msg = MIMEText(f"Your OTP is: {generated_otp}")
                msg['Subject'] = "Voter ID OTP Verification"
                msg['From'] = SENDER_EMAIL
                msg['To'] = user_email
                server = smtplib.SMTP("smtp.gmail.com", 587)
                server.starttls()
                server.login(SENDER_EMAIL, APP_PASSWORD)
                server.send_message(msg)
                server.quit()
                messagebox.showinfo("Success", "OTP Sent Successfully")
            except Exception as e:
                messagebox.showerror("Error", f"Email Failed\n{e}")
    
        def verify_otp():
            global otp_verified
            if otp_var.get() == generated_otp and generated_otp != "":
                otp_verified = True
                messagebox.showinfo("Success", "OTP Verified ✅")
            else:
                otp_verified = False
                messagebox.showerror("Error", "Invalid OTP ❌")
    
        # ---------------- HEADER ----------------
        header = tk.Frame(apply_win, bg="#16a085", height=70)
        header.pack(fill="x")
        header.pack_propagate(False)
        
        tk.Label(header, text="🆔 Apply for New Voter ID",
                 bg="#16a085", fg="white",
                 font=("Segoe UI", 22, "bold")).pack(side="left", padx=20)
    
        tk.Button(header, text="⬅ Back",
                  command=apply_win.destroy,
                  bg="white", fg="#16a085",
                  font=("Segoe UI", 10, "bold")).pack(side="right", padx=20)
    
        # ---------------- SCROLL ----------------
        main = tk.Frame(apply_win, bg="#ecf0f1")
        main.pack(fill="both", expand=True)
    
        canvas = tk.Canvas(main, bg="#ecf0f1")
        scrollbar = tk.Scrollbar(main, orient="vertical", command=canvas.yview)
    
        form_frame = tk.Frame(canvas, bg="#ecf0f1")
        form_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    
        canvas.create_window((0, 0), window=form_frame, anchor="n")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
    
        # ---------------- MAIN CARD ----------------
        container = tk.Frame(form_frame, bg="white", bd=2, relief="ridge",width=1200)
        container.pack(pady=30, padx=80)
        
        tk.Label(container, text="New Voter Registration Form",
                 font=("Segoe UI", 22, "bold"),
                 bg="white").grid(row=0, column=0, columnspan=5, pady=20)
    
        # ---------------- REFACTORED ENTRY (Label on Left) ----------------
        def create_field(parent, label_text, row, col):
            # Label
            lbl = tk.Label(parent, text=label_text, bg="white", font=("Segoe UI", 11, "bold"), anchor="w")
            lbl.grid(row=row, column=col, padx=(20, 5), pady=10, sticky="w")
            
            # Entry Border/Frame
            border = tk.Frame(parent, bg="#bdc3c7", bd=1)
            border.grid(row=row, column=col+1, padx=(5, 20), pady=10, sticky="w")
            
            entry = tk.Entry(border, bd=0, font=("Segoe UI", 11), width=22)
            entry.pack(padx=5, pady=5)
            
            # Focus effects
            entry.bind("<FocusIn>", lambda e: border.config(bg="#16a085"))
            entry.bind("<FocusOut>", lambda e: border.config(bg="#bdc3c7"))
            
            return entry
    
        # ---------------- FIELDS ----------------
        fname   = create_field(container, "First Name:", 1, 0)
        lname   = create_field(container, "Last Name:", 1, 2)
        father  = create_field(container, "Father Name:", 2, 0)
        dob     = create_field(container, "DOB (YYYY-MM-DD):", 2, 2)
        
        # Mobile and Email
        mobile  = create_field(container, "Mobile Number:", 3, 0)
        email   = create_field(container, "Email ID:", 3, 2)
        
        # Aadhar and Gender (Custom Combo)
        aadhar  = create_field(container, "Aadhar Number:", 4, 0)
        
        tk.Label(container, text="Gender:", bg="white", font=("Segoe UI", 11, "bold")).grid(row=4, column=2, padx=(20, 5), sticky="w")
        gender_combo = ttk.Combobox(container, values=["Male", "Female", "Other"], font=("Segoe UI", 11), width=20, state="readonly")
        gender_combo.grid(row=4, column=3, padx=(5, 20), sticky="w")
    
        # Address Section
        house   = create_field(container, "House Number:", 5, 0)
        street  = create_field(container, "Street/Area:", 5, 2)
        village = create_field(container, "Village/Town:", 6, 0)
        post    = create_field(container, "Post Office:", 6, 2)
        district= create_field(container, "District:", 7, 0)
        pin     = create_field(container, "PIN Code:", 7, 2)
        state   = create_field(container, "State:", 8, 0)
    
        # ---------------- PHOTO PANEL ----------------
        right_panel = tk.Frame(container, bg="#f4f6f7", bd=1, relief="solid")
        right_panel.grid(row=1, column=4, rowspan=8, padx=20, pady=10, sticky="n")
    
        tk.Label(right_panel, text="Applicant Photo", font=("Segoe UI", 10, "bold"), bg="#f4f6f7").pack(pady=5)
        photo_frame = tk.Frame(right_panel, width=150, height=150, bg="#ecf0f1", relief="groove", bd=1)
        photo_frame.pack(padx=10)
        photo_frame.pack_propagate(False)
        photo_label = tk.Label(photo_frame, text="No Photo", bg="#ecf0f1")
        photo_label.pack(expand=True)
    
        tk.Label(right_panel, text="Signature", font=("Segoe UI", 10, "bold"), bg="#f4f6f7").pack(pady=5)
        sign_frame = tk.Frame(right_panel, width=150, height=60, bg="#ecf0f1", relief="groove", bd=1)
        sign_frame.pack(padx=10)
        sign_frame.pack_propagate(False)
        sign_label = tk.Label(sign_frame, text="No Signature", bg="#ecf0f1")
        sign_label.pack(expand=True)
    
        def upload_photo():
            global photo_path
            file = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg *.png *.jpeg")])
            if file:
                os.makedirs("photos", exist_ok=True)
                filename = "photos/" + str(uuid.uuid4()) + ".jpg"
        
                img = Image.open(file)
                img.save(filename)
        
                img = img.resize((150, 150))
                photo = ImageTk.PhotoImage(img)
                photo_label.config(image=photo, text="")
                photo_label.image = photo
                photo_path = filename
         
                
        
        def upload_sign():
            global sign_path
            file = filedialog.askopenfilename(filetypes=[("Image Files", "*.jpg *.png *.jpeg")])
            if file:
                os.makedirs("signatures", exist_ok=True)
                filename = "signatures/" + str(uuid.uuid4()) + ".jpg"
        
                img = Image.open(file)
                img.save(filename)
        
                img = img.resize((150, 60))
                sign = ImageTk.PhotoImage(img)
                sign_label.config(image=sign, text="")
                sign_label.image = sign
        
                sign_path = filename
    
        tk.Button(right_panel, text="Upload Photo", bg="#3498db", fg="white", command=upload_photo).pack(pady=5)
        tk.Button(right_panel, text="Upload Signature", bg="#9b59b6", fg="white", command=upload_sign).pack(pady=5)
    
        # ---------------- OTP SECTION ----------------
        otp_var = tk.StringVar()
        otp_frame = tk.Frame(container, bg="white")
        otp_frame.grid(row=10, column=0, columnspan=4, pady=20)
    
        tk.Button(otp_frame, text="Send OTP", bg="#2980b9", fg="white", width=12, command=send_otp).pack(side="left", padx=5)
        tk.Entry(otp_frame, textvariable=otp_var, font=("Segoe UI", 11), width=10, bd=1, relief="solid").pack(side="left", padx=5, ipady=3)
        tk.Button(otp_frame, text="Verify OTP", bg="#27ae60", fg="white", width=12, command=verify_otp).pack(side="left", padx=5)
    
        #---email--
        def send_voter_id_email(receiver_email, eci):
            try:
                msg = MIMEText(f"""
        Your Voter ID is Generated Successfully
        
        ECI Number: {eci}
        
        - Election Commission of India
                """)
                msg['Subject'] = "Voter ID Generated"
                msg['From'] = SENDER_EMAIL
                msg['To'] = receiver_email
        
                server = smtplib.SMTP("smtp.gmail.com", 587)
                server.starttls()
                server.login(SENDER_EMAIL, APP_PASSWORD)
                server.send_message(msg)
                server.quit()
        
            except Exception as e:
                messagebox.showerror("Email Error", str(e))
        # ---------------- VALIDATION & ACTIONS ----------------
        def validate():
            if not re.match(r"^[A-Za-z]{2,30}$", fname.get()):
                messagebox.showerror("Error", "Invalid First Name")
                return False
            if not re.match(r"^\d{12}$", aadhar.get()):
                messagebox.showerror("Error", "Aadhaar must be 12 digits")
                return False
            if not otp_verified:
                messagebox.showerror("Error", "Please verify OTP first")
                return False
            return True
    
        def submit():
            global photo_path, sign_path
        
            if not validate():
                return
        
            if not otp_verified:
                messagebox.showerror("Error", "Verify OTP first")
                return
        
            if photo_path == "" or sign_path == "":
                messagebox.showerror("Error", "Upload Photo & Signature")
                return
        
            try:
                conn = get_db_connection()
                cursor = conn.cursor()
        
                eci = generate_eci()
        
                query = """
                INSERT INTO voter_registration 
                (eci_number, first_name, last_name, father_name, dob, mobile, email,
                 aadhar, gender, house_no, street, village, post_office,
                 district, pin_code, state, photo_path, sign_path)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
        
                values = (
                    eci,
                    fname.get(),
                    lname.get(),
                    father.get(),
                    dob.get(),
                    mobile.get(),
                    email.get(),
                    aadhar.get(),
                    gender_combo.get(),
                    house.get(),
                    street.get(),
                    village.get(),
                    post.get(),
                    district.get(),
                    pin.get(),
                    state.get(),
                    photo_path,
                    sign_path
                )
        
                cursor.execute(query, values)
                conn.commit()
                conn.close()
        
                send_voter_id_email(email.get(), eci)
        
                messagebox.showinfo("Success", f"Voter ID Generated ✅\nECI: {eci}")
        
            except Exception as e:
                messagebox.showerror("Database Error", str(e))
            
        
        def clear():
            for entry in [fname, lname, father, dob, mobile, email, aadhar, house, street, village, post, district, pin, state]:
                entry.delete(0, tk.END)
            gender_combo.set('')
            photo_label.config(image="", text="No Photo")
            sign_label.config(image="", text="No Signature")
    
        # Final Buttons
        btn_frame = tk.Frame(container, bg="white")
        btn_frame.grid(row=11, column=0, columnspan=4, pady=20)
        
        tk.Button(btn_frame, text="Submit Form", bg="#16a085", fg="white", font=("Segoe UI", 12, "bold"), width=20, command=submit).pack(side="left", padx=10)
        tk.Button(btn_frame, text="Clear All", bg="#e74c3c", fg="white", font=("Segoe UI", 12, "bold"), width=20, command=clear).pack(side="left", padx=10)
    
    # To run this standalone for testing:
if __name__ == "__main__":
        root = tk.Tk()
        root.withdraw()
        open_apply_voter_page(root)
        root.mainloop()